package hero;

public class Main {
    public static void main(String[] args) {
        Hero hero=new Wizard("Mikele",5);


        System.out.println(hero);
    }
}
