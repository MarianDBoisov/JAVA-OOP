package SortByNameAndAge;

public class PersonParser {

    public Person person(String line){
        String[] tokens = line.split(" ");


        return new Person(tokens[0],tokens[1],Integer.parseInt(tokens[2]),Double.parseDouble(tokens[3]));
    }
}
