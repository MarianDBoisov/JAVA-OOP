import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {

        Class<Reflection> reflectionClazz = Reflection.class;

        System.out.println(reflectionClazz);
        System.out.println(reflectionClazz.getSuperclass());

        Class<?>[] interfaces = reflectionClazz.getInterfaces();

        for (Class<?> anInterface : interfaces) {
            System.out.println(anInterface);
        }

        System.out.println(reflectionClazz.getDeclaredConstructor().newInstance());


    }
}
